/*---------------------------------------------------------------------*/
/* --- STC MCU Limited ------------------------------------------------*/
/* --- STC 1T Series MCU Demo Programme -------------------------------*/
/* --- Mobile: (86)13922805190 ----------------------------------------*/
/* --- Fax: 86-0513-55012956,55012947,55012969 ------------------------*/
/* --- Tel: 86-0513-55012928,55012929,55012966 ------------------------*/
/* --- Web: www.STCAI.com ---------------------------------------------*/
/* --- BBS: www.STCAIMCU.com  -----------------------------------------*/
/* --- QQ:  800003751 -------------------------------------------------*/
/* ���Ҫ�ڳ�����ʹ�ô˴���,���ڳ�����ע��ʹ����STC�����ϼ�����        */
/*---------------------------------------------------------------------*/

#include "stc.h"
#include "usb.h"
#include "usb_req_class.h"
#include "util.h"


LINECODING LineCoding;
volatile BYTE UsbControlLines;

void usb_req_class()
{
    switch (Setup.bRequest)
    {
    case SET_LINE_CODING:
        usb_set_line_coding();
        break;
    case GET_LINE_CODING:
        usb_get_line_coding();
        break;
    case SET_CONTROL_LINE_STATE:
        usb_set_ctrl_line_state();
        break;
    default:
        usb_setup_stall();
        return;
    }
}

void usb_set_line_coding()
{
    if ((DeviceState != DEVSTATE_CONFIGURED) ||
        (Setup.bmRequestType != (OUT_DIRECT | CLASS_REQUEST | INTERFACE_RECIPIENT)) ||
        Setup.wIndexH != 0 || Setup.wIndexL != 0 || Setup.wLength != 7)
    {
        usb_setup_stall();
        return;
    }

    Ep0State.pData = (BYTE *)&LineCoding;
    Ep0State.wSize = Setup.wLength;

    usb_setup_out();
}

void usb_get_line_coding()
{
    if ((DeviceState != DEVSTATE_CONFIGURED) ||
        (Setup.bmRequestType != (IN_DIRECT | CLASS_REQUEST | INTERFACE_RECIPIENT)) ||
        Setup.wIndexH != 0 || Setup.wIndexL != 0 || Setup.wLength != 7)
    {
        usb_setup_stall();
        return;
    }

    Ep0State.pData = (BYTE *)&LineCoding;
    Ep0State.wSize = Setup.wLength;

    usb_setup_in();
}

void usb_set_ctrl_line_state()
{
    if ((DeviceState != DEVSTATE_CONFIGURED) ||
        (Setup.bmRequestType != (OUT_DIRECT | CLASS_REQUEST | INTERFACE_RECIPIENT)) ||
        Setup.wIndexH != 0 || Setup.wIndexL != 0 || Setup.wLength != 0)
    {
        usb_setup_stall();
        return;
    }

    UsbControlLines=Setup.wValueL&3;
    usb_setup_status();
}

void usb_uart_settings()
{
    if (Setup.bRequest == SET_LINE_CODING)
    {
        LineCoding.bCharFormat = 0;
        LineCoding.bDataBits = 8;
        
        /* Native USB transport: never enable or reconfigure UART pins. */
    }
}